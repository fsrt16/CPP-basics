#include<iostream>
#include<string>
#include<cstring>
using namespace std;
int main(){
char a[100],b[100],j=0,c[100],count=0;
cout<<"Enter a line :  "<<endl;
cin.getline(a,100);
cout<<endl;
cout<<"ENETER A SRTING TO BE SEARCHED FOR   :  "<<endl;
cin.getline(c,100);
int m,n;
m=strlen(a);
n=strlen(c);
for(int i=0;i<m;i++){
	if((a[i]>=65 && a[i]<=90)|| ( a[i]>=97 && a[i]<=122)){
		b[j]=a[i];
		j++;
	}
	
}int b1=0;
for(int i=0;i<m;i++){
	cout<<b[i];
}
cout<<endl;

for(int i=0;i<j;i++){count=0;

	if(b[i]==c[0]){
		
		for(int k=0;k<n;k++)
		if(b[i+k]==c[k]){
			count++;		}
	}
	

		if(count==n){
	b1++;}
	}
	if(b1>0){
		for(int i=0;i<n;i++){
			cout<<b[i];
		}
		cout<<"  occurs "<<b1<<" times ";
	}

	
	return 0;
	}
