#include<iostream>
using namespace std;
int main(){
	int a[5],temp=0;
	for(int i=0;i<5;i++){
		cout<<"ENTER A  ELEMENT "<<i+1<<endl;
		cin>>a[i];
	}
	for(int i=0;i<5;i++)
	{
	
	for(int j=0;j<5-i;j++)
			if(a[j]>a[j+1]){
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
			
		}
	
		cout<<endl<<" [ ";
		for(int i=0;i<5;i++){
			cout<<a[i]<<" ";
		}
		cout<<" ] ";
		cout<<endl<<" [ ";
		for(int i=5;i>0;i--){
			cout<<a[i]<<" ";
		}
		cout<<" ] ";
		return 0;
		
	}

