#include<iostream>
#include<cstring>
#include<string>
#include<fstream>
using namespace std;
struct marks{
	int m[3];
	int rolln ;
};
struct stu{
	char name[30];
	char add[100];
	marks m1;
};

int main(){
	stu b,a;
	fstream t;
	t.open("story.txt",ios::out);
		cout<<"ENETR THE  NAME OF STUDENT "<<endl;
		cin.getline(b.name,30);
		cout<<"ENETR THE  address OF STUDENT "<<endl;
		cin.getline(b.add,100);
		for(int i=0;i<3;i++){
			cout<<"ENTER THE MARKS IN SUB   "<<i+1<<endl;
			cin>>b.m1.m[i];
		}
			cout<<"ENETR THE  rollno OF STUDENT "<<endl;
		cin>>b.m1.rolln; 
		stu *bp;
		bp=&b;
		t<<b.name<<" "<<b.add<<" ";
			for(int i=0;i<3;i++){
		
			t<<b.m1.m[i]<<" ";
		}
		t<<b.m1.rolln;
		t.close();
		return 0;
	
}
