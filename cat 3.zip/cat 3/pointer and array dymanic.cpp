#include<iostream>
using namespace std;
int main(){
	int a[10];
	for(int i=0;i<10;i++){
		cin>>a[i];
	}
	int *p;
	p=a;
	for(int i=0;i<10;i++){
		cout<<*(p+i)<<"    THE ADDRESS IS    :   : "<<(p+i)<<endl;
	}
	int **a1;
	a1=&p;
	cout<<a1;
	return 0;
}
