#include<iostream>
using namespace std;
int main(){int n,m;
	cout<<"ENTER ROWS AND COLUMNS :  "<<endl;
	cin>>n>>m;



int** ary = new int*[n];
for(int i = 0; i < n; ++i)
   ary[i] = new int[m];
   // fill
for(int i=0;i<n;i++){

  for(int j = 0; j < m; ++j)
      {
      	cout<<"ENTER ELEMENT :   "<<endl;
      	cin>>ary[i][j];
	  }
}// print

for(int i = 0; i < n; ++i)
{
  cout<<" [";
    for(int j = 0; j < m; ++j)
     {
	 cout << ary[i][j] ;
	 if(j==m-1)
	 {
	 cout<<" ] ";
	 cout<<endl;}
	 }
	 }
	 // free
for(int i = 0; i < n; ++i)
  delete [] ary[i];
   delete [] ary;
return 0;
}



