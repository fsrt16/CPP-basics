#include <iostream>

using namespace std;

int main()
{
    cout<<"enter a no "<<endl;
    int a , b ;
    cin>>a;
    cout<<"enter another no:"<<endl;
    cin>>b;


for(int i=1,j=1;i,j<=b;i++,j++){
    if(a%i==0,b%j==0){

            while(i==j){
                int a=i;
            }
        }

}
cout<<"the GCD of the given no are --> " << a <<endl;
    return 0;
}
