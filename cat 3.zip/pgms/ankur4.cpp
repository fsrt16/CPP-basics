#include <iostream>
using namespace std;
int main() { int a;
	cout<<"Enter a no : "<<endl;
	cin>>a;
	if(a%2==0){
		cout<<"even"<<endl;
	}
	else{
		cout<<"odd";
	}
	
	return 0;
}
