#include <iostream>
using namespace std;
int main() {
	int a,t;
	cin>>a;
	t=a;
 for(int k=a;k<=t-a;k++){
			cout<<"1";
		}
return 0;
}
